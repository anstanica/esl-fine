<?php

namespace Algolia\AlgoliaSearch\Exceptions;

final class NotFoundException extends BadRequestException
{
}
