<?php

namespace Algolia\AlgoliaSearch\Exceptions;

final class ObjectNotFoundException extends AlgoliaException
{
}
